import { ReactNode } from 'react';
import { Shield, Lock, CheckCircle } from 'lucide-react';

interface AuthLayoutProps {
  children: ReactNode;
  title: string;
  subtitle: string;
}

export function AuthLayout({ children, title, subtitle }: AuthLayoutProps) {
  return (
    <div className="min-h-screen flex">
      {/* Left Panel - Branding */}
      <div className="hidden lg:flex lg:w-1/2 auth-gradient relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-transparent" />
        
        {/* Decorative Elements */}
        <div className="absolute top-20 left-20 w-64 h-64 bg-accent/10 rounded-full blur-3xl floating-animation" />
        <div className="absolute bottom-20 right-20 w-80 h-80 bg-primary-foreground/5 rounded-full blur-3xl floating-animation" style={{ animationDelay: '-2s' }} />
        
        <div className="relative z-10 flex flex-col justify-center px-12 xl:px-20">
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-xl bg-accent/20 flex items-center justify-center">
                <Shield className="w-7 h-7 text-accent" />
              </div>
              <span className="text-2xl font-display font-bold text-primary-foreground">SecureAuth</span>
            </div>
            <h1 className="text-4xl xl:text-5xl font-display font-bold text-primary-foreground mb-4 leading-tight">
              Enterprise-Grade<br />Authentication
            </h1>
            <p className="text-lg text-primary-foreground/70 max-w-md">
              Secure, reliable, and easy to use. Protect your application with industry-standard security practices.
            </p>
          </div>
          
          {/* Features */}
          <div className="space-y-4 mt-8">
            {[
              { icon: Lock, text: 'Password encryption with bcrypt' },
              { icon: Shield, text: 'JWT-based session management' },
              { icon: CheckCircle, text: 'Input validation & sanitization' },
            ].map((feature, index) => (
              <div 
                key={index} 
                className="flex items-center gap-3 text-primary-foreground/80 slide-up"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="w-8 h-8 rounded-lg bg-accent/20 flex items-center justify-center">
                  <feature.icon className="w-4 h-4 text-accent" />
                </div>
                <span>{feature.text}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right Panel - Form */}
      <div className="flex-1 flex flex-col justify-center px-6 py-12 lg:px-8 bg-background">
        <div className="sm:mx-auto sm:w-full sm:max-w-md">
          {/* Mobile Logo */}
          <div className="lg:hidden flex items-center justify-center gap-2 mb-8">
            <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center">
              <Shield className="w-6 h-6 text-primary-foreground" />
            </div>
            <span className="text-xl font-display font-bold text-foreground">SecureAuth</span>
          </div>
          
          <div className="text-center lg:text-left">
            <h2 className="text-2xl lg:text-3xl font-display font-bold text-foreground slide-up">
              {title}
            </h2>
            <p className="mt-2 text-muted-foreground slide-up" style={{ animationDelay: '0.1s' }}>
              {subtitle}
            </p>
          </div>
        </div>

        <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md fade-in" style={{ animationDelay: '0.2s' }}>
          <div className="glass-card rounded-2xl shadow-xl p-8">
            {children}
          </div>
        </div>
      </div>
    </div>
  );
}
