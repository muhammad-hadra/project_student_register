import { ReactNode } from 'react';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';

interface FormFieldProps {
  label: string;
  htmlFor: string;
  error?: string;
  children: ReactNode;
  className?: string;
}

export function FormField({ label, htmlFor, error, children, className }: FormFieldProps) {
  return (
    <div className={cn('space-y-2', className)}>
      <Label 
        htmlFor={htmlFor} 
        className="text-sm font-medium text-foreground"
      >
        {label}
      </Label>
      {children}
      {error && (
        <p className="text-sm text-destructive flex items-center gap-1 animate-in slide-in-from-top-1 duration-200">
          <span className="inline-block w-1 h-1 rounded-full bg-destructive" />
          {error}
        </p>
      )}
    </div>
  );
}
