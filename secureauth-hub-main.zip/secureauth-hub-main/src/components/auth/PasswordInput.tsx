import { useState } from 'react';
import { Eye, EyeOff } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface PasswordInputProps extends React.ComponentProps<typeof Input> {
  showStrength?: boolean;
  strength?: { score: number; label: string; color: string };
}

export function PasswordInput({ 
  className, 
  showStrength = false, 
  strength,
  ...props 
}: PasswordInputProps) {
  const [showPassword, setShowPassword] = useState(false);

  return (
    <div className="space-y-2">
      <div className="relative">
        <Input
          type={showPassword ? 'text' : 'password'}
          className={cn('pr-12', className)}
          {...props}
        />
        <Button
          type="button"
          variant="ghost"
          size="icon"
          className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8 text-muted-foreground hover:text-foreground"
          onClick={() => setShowPassword(!showPassword)}
        >
          {showPassword ? (
            <EyeOff className="h-4 w-4" />
          ) : (
            <Eye className="h-4 w-4" />
          )}
          <span className="sr-only">
            {showPassword ? 'Hide password' : 'Show password'}
          </span>
        </Button>
      </div>
      
      {showStrength && strength && props.value && String(props.value).length > 0 && (
        <div className="space-y-1">
          <div className="flex gap-1">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div
                key={i}
                className={cn(
                  'h-1 flex-1 rounded-full transition-colors duration-200',
                  i <= strength.score ? strength.color : 'bg-muted'
                )}
              />
            ))}
          </div>
          <p className={cn(
            'text-xs font-medium',
            strength.score <= 2 ? 'text-destructive' : 
            strength.score <= 4 ? 'text-auth-warning' : 'text-auth-success'
          )}>
            Password strength: {strength.label}
          </p>
        </div>
      )}
    </div>
  );
}
