import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Loader2, Mail, User, AlertCircle } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { AuthLayout } from '@/components/auth/AuthLayout';
import { FormField } from '@/components/auth/FormField';
import { PasswordInput } from '@/components/auth/PasswordInput';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useToast } from '@/hooks/use-toast';
import { 
  loginSchema, 
  registerSchema, 
  getPasswordStrength,
  type LoginFormData,
  type RegisterFormData
} from '@/lib/validations';

type AuthMode = 'login' | 'register';

export default function Auth() {
  const [mode, setMode] = useState<AuthMode>('login');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  
  // Form state
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  
  const { signIn, signUp, user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  // Redirect if already logged in
  useEffect(() => {
    if (user) {
      navigate('/dashboard');
    }
  }, [user, navigate]);

  const passwordStrength = getPasswordStrength(password);

  const resetForm = () => {
    setName('');
    setEmail('');
    setPassword('');
    setConfirmPassword('');
    setFormErrors({});
    setError(null);
  };

  const switchMode = (newMode: AuthMode) => {
    resetForm();
    setMode(newMode);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setFormErrors({});
    
    // Validate form data
    const formData = mode === 'login' 
      ? { email, password }
      : { name, email, password, confirmPassword };
    
    const schema = mode === 'login' ? loginSchema : registerSchema;
    const result = schema.safeParse(formData);
    
    if (!result.success) {
      const errors: Record<string, string> = {};
      result.error.errors.forEach((err) => {
        if (err.path[0]) {
          errors[err.path[0] as string] = err.message;
        }
      });
      setFormErrors(errors);
      return;
    }

    setLoading(true);
    
    try {
      if (mode === 'login') {
        const { error } = await signIn(email, password);
        if (error) {
          // Handle specific error messages
          if (error.message.includes('Invalid login credentials')) {
            setError('Invalid email or password. Please try again.');
          } else {
            setError(error.message);
          }
        } else {
          toast({
            title: 'Welcome back!',
            description: 'You have successfully logged in.',
          });
          navigate('/dashboard');
        }
      } else {
        const { error } = await signUp(email, password, name);
        if (error) {
          if (error.message.includes('already registered')) {
            setError('An account with this email already exists. Please log in instead.');
          } else {
            setError(error.message);
          }
        } else {
          toast({
            title: 'Account created!',
            description: 'Your account has been created successfully.',
          });
          navigate('/dashboard');
        }
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthLayout
      title={mode === 'login' ? 'Welcome back' : 'Create an account'}
      subtitle={mode === 'login' 
        ? 'Enter your credentials to access your account' 
        : 'Fill in your details to get started'
      }
    >
      <form onSubmit={handleSubmit} className="space-y-5">
        {error && (
          <Alert variant="destructive" className="animate-in slide-in-from-top-2 duration-200">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {mode === 'register' && (
          <FormField label="Full Name" htmlFor="name" error={formErrors.name}>
            <div className="relative">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                id="name"
                type="text"
                placeholder="John Doe"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="pl-10"
                autoComplete="name"
              />
            </div>
          </FormField>
        )}

        <FormField label="Email Address" htmlFor="email" error={formErrors.email}>
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              id="email"
              type="email"
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="pl-10"
              autoComplete="email"
            />
          </div>
        </FormField>

        <FormField label="Password" htmlFor="password" error={formErrors.password}>
          <PasswordInput
            id="password"
            placeholder={mode === 'register' ? 'Create a strong password' : 'Enter your password'}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            showStrength={mode === 'register'}
            strength={passwordStrength}
            autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
          />
        </FormField>

        {mode === 'register' && (
          <FormField label="Confirm Password" htmlFor="confirmPassword" error={formErrors.confirmPassword}>
            <PasswordInput
              id="confirmPassword"
              placeholder="Confirm your password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              autoComplete="new-password"
            />
          </FormField>
        )}

        <Button 
          type="submit" 
          variant="accent"
          size="lg"
          className="w-full"
          disabled={loading}
        >
          {loading && <Loader2 className="h-4 w-4 animate-spin" />}
          {loading 
            ? (mode === 'login' ? 'Signing in...' : 'Creating account...') 
            : (mode === 'login' ? 'Sign In' : 'Create Account')
          }
        </Button>

        <div className="relative my-6">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-border" />
          </div>
          <div className="relative flex justify-center text-xs uppercase">
            <span className="bg-card px-2 text-muted-foreground">
              {mode === 'login' ? 'New to SecureAuth?' : 'Already have an account?'}
            </span>
          </div>
        </div>

        <Button
          type="button"
          variant="outline"
          size="lg"
          className="w-full"
          onClick={() => switchMode(mode === 'login' ? 'register' : 'login')}
        >
          {mode === 'login' ? 'Create an account' : 'Sign in instead'}
        </Button>
      </form>
    </AuthLayout>
  );
}
